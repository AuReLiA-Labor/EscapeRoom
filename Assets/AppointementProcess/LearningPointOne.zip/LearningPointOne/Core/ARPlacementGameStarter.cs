using UnityEngine;

/// <summary>
/// Helper component that listens for the AR placement event and starts the gameplay.
/// Attach this to a GameObject in your scene and assign the references in the Inspector.
/// When the player taps a plane and the AR content is instantiated, this script will
/// show the in‑game UI panel and start the countdown timer.
/// </summary>
public class ARPlacementGameStarter : MonoBehaviour
{
    [Tooltip("The ARContentPlacer responsible for placing the AR room.")]
    public ARContentPlacer placer;

    [Tooltip("The flow controller used to show/hide the UI panels.")]
    public ARFlow arFlow;

    private bool _subscribed;

    private void Awake()
    {
        // Subscribe as early as possible; if placer is already assigned we can wire up now.  
        TrySubscribe();
    }

    private void OnEnable()
    {
        TrySubscribe();
    }

    private void OnDisable()
    {
        if (placer != null && _subscribed)
        {
            placer.Placed -= OnPlaced;
            _subscribed = false;
        }
    }

    private void TrySubscribe()
    {
        if (placer != null && !_subscribed)
        {
            placer.Placed += OnPlaced;
            _subscribed = true;
        }
    }

    private void OnPlaced()
    {
        // Once the AR content has been placed we can reveal the in‑game HUD and kick off the game.
        if (arFlow != null)
            arFlow.ShowInGamePanel();

        // Start the gameplay timer via the GameManager singleton.
        if (GameManager.Instance != null)
            GameManager.Instance.StartGameplay();
    }
}