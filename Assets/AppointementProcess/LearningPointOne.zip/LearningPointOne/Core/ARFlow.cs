using UnityEngine;
using UnityEngine.UI;

public class ARFlow : MonoBehaviour
{
    [Header("Top-level canvases / roots")]
    [SerializeField] private GameObject welcomeCanvas;     // initial "Start" screen
    [SerializeField] private GameObject howToScanCanvas;   // shows instructions
    [SerializeField] private GameObject scanningCanvas;    // empty/overlay while scanning
    [SerializeField] private GameObject inGameCanvas;      // parent for in-game panels (children below)

    [Header("In-game panels (children of inGameCanvas)")]
    [SerializeField] private GameObject learningPointWelcomePanel; // has the Play button
    [SerializeField] private GameObject timeScorePanel;            // HUD with score & timer
    [SerializeField] private GameObject failPanel;
    [SerializeField] private GameObject successPanel;

    [Header("AR content")]
    [SerializeField] private GameObject arContentRoot;          // root that enables AR session/managers & placer
    [SerializeField] private ARContentPlacer contentPlacer;     // optional: to hide scanning once placed

    [Header("Buttons (optional, if wired via Inspector)")]
    [SerializeField] private Button startButton;   // Start on welcome
    [SerializeField] private Button scanButton;    // Continue from how-to into scanning
    [SerializeField] private Button playButton;    // Play on LearningPointWelcome
    [SerializeField] private Button restartButtonsFail;   // Restart on Fail panel
    [SerializeField] private Button restartButtonsSuccess;// Restart on Complete panel
    [SerializeField] private Button closeFailButton;      // Optional: close Fail back to Welcome
    [SerializeField] private Button closeSuccessButton;   // Optional: close Success back to Welcome

    [Header("Behaviour")]
    [Tooltip("If ON, tapping Scan jumps straight to gameplay (disable to match desired flow).")]
    public bool autoEnterGameOnScan = false; // <- make sure to UNCHECK in Inspector

    void Awake()
    {
        // Hook buttons if provided
        if (startButton) startButton.onClick.AddListener(OnStartButtonClicked);
        if (scanButton) scanButton.onClick.AddListener(OnScanButtonClicked);
        if (playButton) playButton.onClick.AddListener(OnPlayButtonClicked);

        if (restartButtonsFail) restartButtonsFail.onClick.AddListener(OnRestartButtonClicked);
        if (restartButtonsSuccess) restartButtonsSuccess.onClick.AddListener(OnRestartButtonClicked);
        if (closeFailButton) closeFailButton.onClick.AddListener(ShowWelcome);
        if (closeSuccessButton) closeSuccessButton.onClick.AddListener(ShowWelcome);

        if (contentPlacer)
            contentPlacer.Placed += OnContentPlaced; // just to hide scanning overlay when placed
    }

    void OnDestroy()
    {
        if (contentPlacer)
            contentPlacer.Placed -= OnContentPlaced;
    }

    void Start()
    {
        ShowWelcome();
    }

    // ====== Public helpers other scripts can call ======

    public void ShowLearningWelcome()
    {
        ToggleAll(welcome: false, howTo: false, scanning: false, inGame: true);

        // In-game subpanels
        SetActiveSafe(learningPointWelcomePanel, true);
        SetActiveSafe(timeScorePanel, false);
        SetActiveSafe(failPanel, false);
        SetActiveSafe(successPanel, false);
    }

    public void ShowInGamePanel()
    {
        ToggleAll(welcome: false, howTo: false, scanning: false, inGame: true);
        SetActiveSafe(learningPointWelcomePanel, false);
        SetActiveSafe(timeScorePanel, true);
    }

    public void ShowWelcome()
    {
        ToggleAll(welcome: true, howTo: false, scanning: false, inGame: false);
        if (GameManager.Instance) GameManager.Instance.ResetGame();
    }

    // ====== Button handlers ======

    private void OnStartButtonClicked()
    {
        ToggleAll(welcome: false, howTo: true, scanning: false, inGame: false);
    }

    private void OnScanButtonClicked()
    {
        if (autoEnterGameOnScan)
        {
            // Legacy/optional behaviour: jump straight in (NOT desired for your flow)
            ShowInGamePanel();
            GameManager.Instance?.StartGameplay();
            return;
        }

        // Desired behaviour: enter scanning state, enable AR systems, wait for placement
        ToggleAll(welcome: false, howTo: false, scanning: true, inGame: false);
        SetActiveSafe(arContentRoot, true);
    }

    private void OnPlayButtonClicked()
    {
        // Player is inside the room; now start the gameplay & show HUD
        SetActiveSafe(learningPointWelcomePanel, false);
        SetActiveSafe(timeScorePanel, true);

        GameManager.Instance?.StartGameplay();
    }

    private void OnRestartButtonClicked()
    {
        // Clear win/fail and return to Welcome
        SetActiveSafe(failPanel, false);
        SetActiveSafe(successPanel, false);
        ShowWelcome();
    }

    // ====== Callbacks ======

    private void OnContentPlaced()
    {
        // Once the GameRoot is placed, we can hide scanning overlay
        SetActiveSafe(scanningCanvas, false);
        // Keep AR content active; entrance logic and canvases take over next
    }

    // ====== Utils ======

    private void ToggleAll(bool welcome, bool howTo, bool scanning, bool inGame)
    {
        SetActiveSafe(welcomeCanvas, welcome);
        SetActiveSafe(howToScanCanvas, howTo);
        SetActiveSafe(scanningCanvas, scanning);
        SetActiveSafe(inGameCanvas, inGame);
        // AR on during scanning; off otherwise unless you want it to persist
        if (arContentRoot) arContentRoot.SetActive(scanning);
    }

    private static void SetActiveSafe(GameObject go, bool active)
    {
        if (go && go.activeSelf != active) go.SetActive(active);
    }

}
