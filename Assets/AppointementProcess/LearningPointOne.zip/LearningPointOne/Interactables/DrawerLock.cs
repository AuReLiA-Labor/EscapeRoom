using UnityEngine;

public class DrawerLock : MonoBehaviour
{
    [Header("Drawer Movement")]
    [SerializeField] private Transform drawerTransform;   // The drawer object to move (defaults to this transform)
    [SerializeField] private float openX = 0.1f;          // Target local X when opened

    [Header("Contents")]
    [SerializeField] private GameObject itemInside;

    public bool IsUnlocked { get; private set; }
    bool _opened;
    Vector3 _closedLocalPos;

    private void Awake()
    {
        if (drawerTransform == null)
            drawerTransform = transform;

        _closedLocalPos = drawerTransform.localPosition;
    }

    // Call to unlock (without opening)
    public void Unlock()
    {
        IsUnlocked = true;
    }

    // Call to unlock and open; reveals item
    public void UnlockAndOpen()
    {
        IsUnlocked = true;
        Open();
    }

    // Open the drawer if unlocked (no animation; moves X to openX)
    public void Open()
    {
        if (_opened || !IsUnlocked) return;

        var p = drawerTransform.localPosition;
        p.x = openX;
        drawerTransform.localPosition = p;

        if (itemInside) itemInside.SetActive(true);
        _opened = true;
    }

    // Reset state for restarts
    public void ResetState()
    {
        IsUnlocked = false;
        _opened = false;

        if (drawerTransform)
            drawerTransform.localPosition = _closedLocalPos;

        if (itemInside) itemInside.SetActive(false);
    }
}