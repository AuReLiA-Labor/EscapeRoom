using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class ARContentPlacer : MonoBehaviour
{
    [Header("Scene Refs")]
    [SerializeField] private Camera arCamera;           // AR Camera
    [SerializeField] private GameObject gameRoot;       // Your gameplay root to place (keep inactive in the prefab/scene)
    [SerializeField] private GameObject placementIndicator; // Little visual that sits where placement will happen

    [Header("Behaviour")]
    [Tooltip("Only allow placement on upward-facing horizontal planes.")]
    [SerializeField] private bool onlyHorizontalUp = true;

    [Tooltip("Extra height to keep the root above the plane (meters).")]
    [SerializeField] private float yOffset = 0.0f;

    [Tooltip("Hide all detected planes after placement.")]
    [SerializeField] private bool hidePlanesAfterPlacement = true;

    private ARRaycastManager _raycastManager;
    private ARPlaneManager _planeManager;

    private bool _placed;
    private static readonly List<ARRaycastHit> _hits = new List<ARRaycastHit>();

    public event System.Action Placed; // Optional: subscribe from UI flow if you want

    private void Awake()
    {
        _raycastManager = GetComponent<ARRaycastManager>() ?? GetComponentInParent<ARRaycastManager>();
        _planeManager   = GetComponent<ARPlaneManager>()   ?? GetComponentInParent<ARPlaneManager>();

        if (arCamera == null)
        {
            var cam = Camera.main;
            if (cam != null) arCamera = cam;
        }
    }

    private void Start()
    {
        if (gameRoot != null) gameRoot.SetActive(false);
        if (placementIndicator != null) placementIndicator.SetActive(false);
    }

    private void Update()
    {
        if (_placed || _raycastManager == null) return;

        UpdateIndicator();

        // Simple tap to place
        if (Input.touchCount == 0) return;
        var touch = Input.GetTouch(0);
        if (touch.phase != TouchPhase.Began) return;
        if (IsPointerOverUI(touch.fingerId)) return;

        if (_raycastManager.Raycast(touch.position, _hits, TrackableType.PlaneWithinPolygon))
        {
            var pose = _hits[0].pose;

            if (onlyHorizontalUp && _planeManager != null)
            {
                var plane = _planeManager.GetPlane(_hits[0].trackableId);
                if (plane != null && plane.alignment != PlaneAlignment.HorizontalUp)
                    return; // ignore non-upward planes
            }

            PlaceAt(pose);
        }
    }

    private void UpdateIndicator()
    {
        if (placementIndicator == null) return;

        var center = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
        if (_raycastManager.Raycast(center, _hits, TrackableType.PlaneWithinPolygon))
        {
            var pose = _hits[0].pose;
            if (onlyHorizontalUp && _planeManager != null)
            {
                var plane = _planeManager.GetPlane(_hits[0].trackableId);
                if (plane != null && plane.alignment != PlaneAlignment.HorizontalUp)
                {
                    placementIndicator.SetActive(false);
                    return;
                }
            }

            placementIndicator.transform.SetPositionAndRotation(
                pose.position + Vector3.up * yOffset,
                YawFacingCamera()
            );
            placementIndicator.SetActive(true);
        }
        else
        {
            placementIndicator.SetActive(false);
        }
    }

    private void PlaceAt(Pose pose)
    {
        var pos = pose.position + Vector3.up * yOffset;
        var rot = YawFacingCamera();

        if (gameRoot != null)
        {
            gameRoot.transform.SetPositionAndRotation(pos, rot);
            gameRoot.SetActive(true);
        }

        if (placementIndicator != null)
            placementIndicator.SetActive(false);

        if (hidePlanesAfterPlacement && _planeManager != null)
        {
            foreach (var plane in _planeManager.trackables)
                plane.gameObject.SetActive(false);
            _planeManager.enabled = false;
        }

        _placed = true;
        Placed?.Invoke(); // notify flow/UI if you want
    }

    private Quaternion YawFacingCamera()
    {
        if (arCamera == null) return Quaternion.identity;
        var fwd = arCamera.transform.forward;
        fwd.y = 0f;
        if (fwd.sqrMagnitude < 0.0001f) fwd = Vector3.forward;
        return Quaternion.LookRotation(fwd.normalized, Vector3.up);
    }

    private static bool IsPointerOverUI(int touchId)
    {
        if (EventSystem.current == null) return false;
        // Works for both mouse (returns true with no arg) and touch (fingerId)
        return EventSystem.current.IsPointerOverGameObject() ||
               EventSystem.current.IsPointerOverGameObject(touchId);
    }
}
